# Multi Step Form with JS Validation & SPAM Blocker

A Pen created on CodePen.io. Original URL: [https://codepen.io/wortmann/pen/LEBELj](https://codepen.io/wortmann/pen/LEBELj).

Forked from [Atakan Goktepe](http://codepen.io/atakan/)'s Pen [Multi Step Form with Progress Bar using jQuery and CSS3](http://codepen.io/atakan/pen/gqbIz/).

Uses [VTCHA](https://github.com/wolf-w/pastebox/tree/master/vtcha) to block spambots