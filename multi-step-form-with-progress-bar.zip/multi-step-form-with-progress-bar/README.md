# Multi-step form with progress bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/brendansparrow/pen/QjRmKv](https://codepen.io/brendansparrow/pen/QjRmKv).

Borrowed heavily from: http://thecodeplayer.com/walkthrough/jquery-multi-step-form-with-progress-bar